package org.example;

public class Driver {

    public static void main(String[] args) {

        // https://attacomsian.com/blog/java-read-write-json-files

        String jsonData = JSONUtilities.readJSONFromFile("jsonData.json");

        System.out.println(jsonData);

        JSONUtilities.writeJSONToFile(jsonData, "jsonData.json");

    }
}
