package org.example;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class JSONUtilities {

    public static String readJSONFromFile(String pathToFile) {
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
        JSONArray jsonData = null;

        try (FileReader reader = new FileReader(System.getProperty("user.dir") + "/" + pathToFile)) {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
            jsonData = (JSONArray) obj;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return jsonData.toJSONString();
    }

    public static void writeJSONToFile(String jsonData, String pathToFile) {

        //Write JSON file
        try (FileWriter file = new FileWriter(System.getProperty("user.dir") + "/" + pathToFile)) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(jsonData);
            file.flush();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
